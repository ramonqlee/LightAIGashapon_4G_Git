-- @module Consts
-- @author ramonqlee
-- @copyright idreems.com
-- @release 2017.12.24
module(...,package.seeall)


MQTT_PROTOCOL = "tcp"--MQTT协议
MQTT_ADDR = "mq.azls.mobi"--"azls.mobi"
MQTT_PORT = 1884--MQTT端口号
MQTT_CONFIG_NODEID_URL_FORMATTER="http://j.azls.mobi/node/register?imei=%s&sn=%s"--配置点位id /node/register?imei=869300038726885&sn=C6BAFBA65D961F5E305DC2ACFC24A9C6 

MQTT_TASK_URL_FORMATTER="http://j.azls.mobi/vm/get_task?node_id=%s&nonce=%s&timestamp=%s&sign=%s"

MQTT_TWINKLE_URL_FORMATTER = "http://j.azls.mobi/node/twinkle?node_id=%s"


